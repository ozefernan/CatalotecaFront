<div class="pg-detalhe-produto-lampada-fluorescente-espiral-22v-philips pg-detalhe-produto">
    <?php
    $pg = 'detalhe-produto-lampada-fluorescente-espiral-22v-philips';
    $titulo = 'Lâmpada Fluorescente Eletrônica Espiral 20W 220V E27 Branca Eco Home Twister - Philips';
    $description = 'Saiba os detalhes técnicos do produto';
    include('head.php');
    include('menu-pesquisa.php');
    include('menu-filtro.php');
    include('menu-busca-relacionada.php');
    ?>

    <section class="s-padrao s-visao-geral-produto" style="padding-top: 1em;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <a class="btn btn-link" href="categoria-produto-lampada.php" title="Voltar à lista"
                       style="padding-bottom: 1em;">Voltar à
                        lista</a>
                    <div class="s-visao-geral-produto-b-conteudo">
                        <div class="row">

                            <!-- Galeria produto -->
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="c-galeria-produto xzoom-wrapper">

                                    <!-- Nome do produto para o mobile -->
                                    <p class="h2 visible-xs no-margin">Lâmpada Fluorescente Eletrônica Espiral 20W 220V E27 Branca Eco Home Twister</p>

                                    <div class="c-galeria-produto-b-img-destacada">

                                        <img class="img-responsive c-galeria-produto-img-destacada xzoom"
                                             alt="Lâmpada Fluorescente Eletrônica Espiral 20W 220V E27 Branca Eco Home Twister"
                                             src="assets/images/produtos/lampada/philips/img-detalhe/preview/lampada-fluorescente-espiral-22v-philips.png"
                                             xoriginal="assets/images/produtos/lampada/philips/img-detalhe/zoom/lampada-fluorescente-espiral-22v-philips.png">
                                    </div>

                                    <div class="c-galeria-produto-b-listagem-thumbnail xzoom-thumbs carousel slide"
                                         id="carousel-produto-thumbs" data-ride="carousel" data-type="multi"
                                         data-interval="false">

                                        <div class="carousel-inner">

                                            <div class="item active">
                                                <div class="col-xs-3 col-sm-3 col-md-3 col-thumbnail-item">
                                                    <div class="c-galeria-produto-listagem-thumbnail-item active">
                                                        <a class="c-galeria-produto-listagem-thumbnail-link-item"
                                                           href="assets/images/produtos/lampada/philips/img-detalhe/zoom/lampada-fluorescente-espiral-22v-philips.png">
                                                            <img class="img-responsive c-galeria-produto-listagem-thumbnail-img xzoom-gallery"
                                                                 alt="Imagem 1"
                                                                 src="assets/images/produtos/lampada/philips/img-detalhe/preview/lampada-fluorescente-espiral-22v-philips.png"
                                                                 xpreview="assets/images/produtos/lampada/philips/img-detalhe/preview/lampada-fluorescente-espiral-22v-philips.png">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Controls -->
                                        <div class="left carousel-control">
                                            <a href="#carousel-produto-thumbs" role="button" data-slide="prev">
                                                <span class="fas fa-chevron-left" aria-hidden="true"></span>
                                                <span class="sr-only">Anterior</span>
                                            </a>
                                        </div>
                                        <div class="right carousel-control">
                                            <a href="#carousel-produto-thumbs" role="button" data-slide="next">
                                                <span class="fas fa-chevron-right" aria-hidden="true"></span>
                                                <span class="sr-only">Próximo</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /Galeria produto -->

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="s-visao-geral-produto-b-conteudo-descricoes">
                                    <h1 class="h2 hidden-xs">Lâmpada Fluorescente Eletrônica Espiral 20W 220V E27 Branca Eco Home Twister</h1>
                                    <p>Cód: <span>929689837211</span> Produto consta em sua base no Cataloteca.</p>

                                    <div class="b-avaliacao">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        1 opinião
                                    </div>

                                    <div class="s-visao-geral-produto-b-conteudo-descricoes-marca">
                                        <p>Marca:</p>
                                        <div class="s-visao-geral-produto-b-conteudo-descricoes-marca ">
                                            <a href="#" title="Veja os produtos dessa marca"><img
                                                    class="s-visao-geral-produto-b-conteudo-descricoes-marca-img card-padrao"
                                                    src="assets/images/marcas/logo-marca-philips.png"></a>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>

                                    <p>Lâmpada Fluorescente Eletrônica Espiral 20W 220V E27 Branca Eco Home Twister</p>

                                    <a class="btn btn-default btn-md" title="Adicionar à lista" href="#">Adicionar à
                                        lista</a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="s-padrao s-tab-detalhe-produto half-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="s-tab-detalhe-produto-box">


                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="nav-tabs-item active">
                                <a href="#dados-tecnicos" aria-controls="dados-tecnicos" role="tab" data-toggle="tab">
                                    Dados Técnicos</a>
                            </li>
                            <li role="presentation" class="nav-tabs-item">
                                <a href="#descricao-completa" aria-controls="descricao-completa" role="tab"
                                   data-toggle="tab">
                                    Descrição Completa
                                </a>
                            </li>
                            <li role="presentation" class="nav-tabs-item">
                                <a href="#catalogo-certificados" aria-controls="catalogo-certificados" role="tab"
                                   data-toggle="tab">
                                    Catálogos / Certificados
                                </a>
                            </li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content tab-detalhe-produto">
                            <div role="tabpanel" class="tab-pane fade in active" id="dados-tecnicos">

                                <div class="table-responsive">
                                    <table class="table">
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Potência (W):</td>
                                            <td class="tab-detalhe-produto-item-descricao">20</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Bulbo:</td>
                                            <td class="tab-detalhe-produto-item-descricao">E27</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Diâmetro do Bulbo (mm):</td>
                                            <td class="tab-detalhe-produto-item-descricao">54</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Comprimento (mm):</td>
                                            <td class="tab-detalhe-produto-item-descricao">135</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Fluxo Luminoso (LM):</td>
                                            <td class="tab-detalhe-produto-item-descricao">1185</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Índice de Reprodução de Cor (IRC):</td>
                                            <td class="tab-detalhe-produto-item-descricao">80</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Eficiência Luminosa (Lm/W):</td>
                                            <td class="tab-detalhe-produto-item-descricao">64</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Vida Média (h):</td>
                                            <td class="tab-detalhe-produto-item-descricao">6000</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Tensão (V):</td>
                                            <td class="tab-detalhe-produto-item-descricao">220</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Cor:</td>
                                            <td class="tab-detalhe-produto-item-descricao">Branca</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Base:</td>
                                            <td class="tab-detalhe-produto-item-descricao">E27</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Fluxo Luminoso:</td>
                                            <td class="tab-detalhe-produto-item-descricao">1185</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Quantidade por embalagem (PÇ):</td>
                                            <td class="tab-detalhe-produto-item-descricao">10</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Marca:</td>
                                            <td class="tab-detalhe-produto-item-descricao">Philips</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Unidade:</td>
                                            <td class="tab-detalhe-produto-item-descricao">Peça</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Peso (KG):</td>
                                            <td class="tab-detalhe-produto-item-descricao">0.83</td>
                                        </tr>
                                        <tr>
                                            <td class="tab-detalhe-produto-item-titulo">Referência:</td>
                                            <td class="tab-detalhe-produto-item-descricao">929689837211</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="descricao-completa">
                                <p>...</p>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="catalogo-certificados">
                                <a href="http://www.kennedyeletrica.com.br/catalogos/Philips-iluminacao.pdf" target="_blank" title="Veja o item no Catálogo do Fabricante">Veja o item no Catálogo do Fabricante</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="s-padrao s-avaliacao-produto no-padding-top">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Principais avaliações</h2>
                    <div class="c-avaliacao-produto">
                        <div class="c-avaliacao-produto-box">
                            <div class="c-avaliacao-produto-topo">

                                <div class="col-xs-5 col-sm-4 col-md-4">
                                    <div class="c-avaliacao-produto-topo-nota">
                                        <span class="h1 pull-left">4</span>
                                    </div>

                                    <div class="c-avaliacao-produto-topo-avaliacao">
                                        <div class="c-avaliacao-produto-topo-avaliacao-estrela">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star "></span>
                                        </div>
                                        <p>Média entre 1 avaliação</p>
                                    </div>
                                </div>

                                <div class="col-xs-7 col-sm-5 col-md-5">
                                    <div class="c-avaliacao-barra-progresso-circular">
                                        <div class="set-size charts-container">
                                            <div class="pie-wrapper progress-90 style-2">
                                                <span class="label">90%</span>
                                                <div class="pie">
                                                    <div class="left-side half-circle"></div>
                                                    <div class="right-side half-circle"></div>
                                                </div>
                                                <div class="shadow"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="c-avaliacao-produto-topo-avaliacao-descricao-grafico">
                                        dos clientes recomendam este produto
                                    </p>
                                </div>

                                <div class="col-xs-7 col-sm-3 col-md-3">
                                    <a class="btn btn-outline btn-default btn-md pull-right" title="Adicionar à lista"
                                       href="#">Avaliar
                                        produto</a>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <div class="c-avaliacao-produto-listagem">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-10 col-md-10">
                                        <!-- Item -->
                                        <div class="c-avaliacao-produto-listagem-item">

                                            <div class="col-xs-12 col-sm-2 col-md-2">
                                                <div class="c-avaliacao-produto-listagem-item-img">
                                                    <img class="img-circle"
                                                         src="assets/images/depoimentos/depoimento-1.png">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-10 col-md-10">
                                                <div class="c-avaliacao-produto-listagem-item-topo">
                                                    <h2 class="h4">Paulo Felipe</h2>
                                                    <div class="c-avaliacao-produto-listagem-item-topo-estrela">
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star checked"></span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="c-avaliacao-produto-listagem-item-descricao">
                                                    <p>Ótimo produto! De fácil instalação e compactas. Perfeitas para ambientes grandes.</p>
                                                    <a class="btn btn-link" href="javascrip:void(0);">Ver avaliação completa</a>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /Item -->

                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="text-center" style="margin-top: 1em;">
                        <a class="btn btn-default btn-lg" title="Veja todas as opiniões" href="javascrip:void(0);">Ver todos as
                            opiniões</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Produtos sugeridos -->
    <section class="s-padrao s-produto-sugerido half-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Confira outras lâmpadas sugeridas para você:</h2>
                </div>
                <div class="slide-produto slide-produto-default">
                    <div class="MultiCarousel" data-items="2,3,4,4" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ourolux-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ge-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/brilia-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>


                        </div>
                        <button class="btn btn-primary btn-arrow leftLst"><</button>
                        <button class="btn btn-primary btn-arrow rightLst">></button>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Produtos do mesmo fabricante -->
    <section class="s-padrao s-produto-relacionado-fabricante no-padding-top half-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Outros produtos da marca Philips:</h2>
                </div>
                <div class="slide-produto slide-produto-default">
                    <div class="MultiCarousel" data-items="2,3,4,4" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="detalhe-produto-lampada-vapor-metalico-ovoid-philips.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produtos/lampada/philips/lampada-vapor-ovoide-4300k-philips.png"
                                                 alt="Lâmpada Vapor Metálico Ovóide 250W E40 4300K-IRC69">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ourolux-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ge-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/brilia-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>


                        </div>
                        <button class="btn btn-primary btn-arrow leftLst"><</button>
                        <button class="btn btn-primary btn-arrow rightLst">></button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Produtos em alta -->
    <section class="s-padrao s-produto-alta no-padding-top">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Produtos em Alta na Cataloteca:</h2>
                </div>
                <div class="slide-produto slide-produto-default">
                    <div class="MultiCarousel" data-items="2,3,4,4" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ourolux-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ge-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/brilia-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>


                        </div>
                        <button class="btn btn-primary btn-arrow leftLst"><</button>
                        <button class="btn btn-primary btn-arrow rightLst">></button>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="s-padrao s-quem-visitou-categoria">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Quem visitou esta categoria também viu estes produtos:</h2>
                </div>
                <div class="slide-produto slide-produto-small">
                    <div class="MultiCarousel" data-items="2,3,5,6" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <div class="b-slide-produto-item-img">
                                                <img src="assets/images/produtos/quem-visitou/cabos-e-fios-1.png" alt=""
                                                     class="slide-produto-item-img">
                                            </div>
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Cabos e fios
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/componentes-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Componentes Elétricos
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/eletroduto-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Eletroduto
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/extensoes-filtros-1.png"
                                                 alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Extensões e filtros de linha
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/interruptor-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Interruptor
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/seguranca-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Segurança elétrica
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <div class="b-slide-produto-item-img">
                                                <img src="assets/images/produtos/quem-visitou/cabos-e-fios-1.png" alt=""
                                                     class="slide-produto-item-img">
                                            </div>
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Cabos e fios
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/componentes-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Componentes Elétricos
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/eletroduto-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Eletroduto
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/extensoes-filtros-1.png"
                                                 alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Extensões e filtros de linha
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/interruptor-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Interruptor
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/seguranca-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Segurança elétrica
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-arrow leftLst"><</button>
                        <button class="btn btn-primary btn-arrow rightLst">></button>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <a class="btn btn-default btn-lg" href="#">Ver todas as categorias</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('footer.php'); ?>
</div>