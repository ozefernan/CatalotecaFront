<!-- Menu pesquisa -->
<div class="c-menu-pesquisa">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-3 col-md-3">
                <div class="logo">
                    <a href="index.php" title="Cataloteca"><img class="img-logo" src="assets/images/cataloteca-logo.svg"
                                                                alt="Cataloteca"> </a>
                </div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-7">
                <form class="form-inline" method="get" action="categoria-produto.php">
                    <input class="form-control" type="text"
                           placeholder="Pesquise por produtos, marca ou característica..." aria-label="Search">
                    <button class="btn btn-search-form" type="submit"><img src="assets/images/icones/icon-search.svg">
                    </button>
                </form>
            </div>

            <div class="col-xs-12 col-sm-3 col-md-2 hidden-xs">
                <ul class="list-inline pull-right c-menu-pesquisa-menu">
                    <li><a class="<?php echo $pg == 'cadastro' ? 'active' : ''; ?>" href="cadastro.php" title="Cadastro">Cadastro</a></li>
                    <li><a class="<?php echo $pg == 'login' ? 'active' : ''; ?>" href="login.php" title="Login">Login</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--/ Menu pesuisa -->