<div class="pg-categoria-produto">
    <?php
    $pg = 'categoria-produyto';
    $titulo = 'Categoria do produto';
    $description = 'Encontre produtos de uma categoria específica';
    include('head.php');
    include('menu-pesquisa.php');
    include('menu-filtro.php');
    include('menu-busca-relacionada.php');

    ?>

    <section class="s-padrao" style="background-color: #f9f9f9; padding-top: 3em;">
        <div class="container">
            <div class="row">
                <div class="pull-right col-xs-12 col-sm-8 col-md-9">

                    <div class="half-padding-bottom">
                        <h2 class="h4">Busca por marcas</h2>

                        <div class="c-listagem-marca">
                            <div class="row">
                                <div class="col-sm-12 col-md-9">
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-2 col-md-2">
                                            <a href="#" class="c-listagem-marca-item">
                                                <div class="c-listagem-marca-item-img">
                                                    <img src="assets/images/fabricante/brilia-2.png"
                                                         alt="Conheça os produtos dessa marca">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-4 col-sm-2 col-md-2">
                                            <a href="#" class="c-listagem-marca-item"
                                               title="Veja os produtos dessa marca">
                                                <div class="c-listagem-marca-item-img">
                                                    <img src="assets/images/fabricante/galaxy-2.png"
                                                         alt="Conheça os produtos dessa marca">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-4 col-sm-2 col-md-2">
                                            <a href="#" class="c-listagem-marca-item"
                                               title="Veja os produtos dessa marca">
                                                <div class="c-listagem-marca-item-img">
                                                    <img src="assets/images/fabricante/ourolux-2.png"
                                                         alt="Conheça os produtos dessa marca">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-4 col-sm-2 col-md-2">
                                            <a href="#" class="c-listagem-marca-item"
                                               title="Veja os produtos dessa marca">
                                                <div class="c-listagem-marca-item-img">
                                                    <img src="assets/images/fabricante/philips-2.png"
                                                         alt="Conheça os produtos dessa marca">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-4 col-sm-2 col-md-2">
                                            <a href="#" class="c-listagem-marca-item"
                                               title="Veja os produtos dessa marca">
                                                <div class="c-listagem-marca-item-img">
                                                    <img src="assets/images/fabricante/ge-2.png"
                                                         alt="Conheça os produtos dessa marca">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-4 col-sm-2 col-md-2">
                                            <a href="#" class="c-listagem-marca-item"
                                               title="Veja os produtos dessa marca">
                                                <div class="c-listagem-marca-item-img">
                                                    <img src="assets/images/fabricante/brilia-2.png"
                                                         alt="Conheça os produtos dessa marca">
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-3">
                                    <button type="button" class="btn btn-link" data-toggle="modal" data-target="#modalTodasMarcas">
                                        Ver todas as marcas
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="">
                        <h2 class="h3">Produtos encontrados</h2>

                        <div class="c-lista-produto-linha">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">

                                    <!-- Item listagem em linha -->
                                    <div class="c-lista-produto-linha-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto" style="width: 100%;">
                                            <div class="col-xs-4 col-sm-4 col-md-3">
                                                <div class="c-lista-produto-linha-item-img">
                                                    <img src="assets/images/produto/prod-1.png"
                                                         alt="Interruptor Fuga Dr C/2 Polos 125a 30ma - Steck">
                                                </div>
                                            </div>

                                            <div class="col-xs-8 col-sm-8 col-md-9">
                                                <div class="c-lista-produto-linha-item-conteudo">
                                                    <h2 class="c-lista-produto-linha-item-titulo h4">Interruptor Fuga Dr
                                                        C/2 Polos
                                                        125a 30ma - Steck</h2>
                                                    <div class="c-lista-produto-linha-item-fabricante-img">
                                                        <img src="assets/images/fabricante/ge-2.png"
                                                             alt="Philips">
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div> <!-- Fim item listagem em linha -->

                                    <!-- Item listagem em linha -->
                                    <div class="c-lista-produto-linha-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto" style="width: 100%;">
                                            <div class="col-xs-4 col-sm-4 col-md-3">
                                                <div class="c-lista-produto-linha-item-img">
                                                    <img src="assets/images/produto/prod-2.png"
                                                         alt="Interruptor Simples Miluz Sobrepor S3b66100 Branco">
                                                </div>
                                            </div>

                                            <div class="col-xs-8 col-sm-8 col-md-9">
                                                <div class="c-lista-produto-linha-item-conteudo">
                                                    <h2 class="c-lista-produto-linha-item-titulo h4">Interruptor Simples
                                                        Miluz Sobrepor S3b66100 Branco</h2>
                                                    <div class="c-lista-produto-linha-item-fabricante-img">
                                                        <img src="assets/images/fabricante/ourolux-2.png"
                                                             alt="Philips">
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div> <!-- Fim item listagem em linha -->

                                    <!-- Item listagem em linha -->
                                    <div class="c-lista-produto-linha-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto" style="width: 100%;">
                                            <div class="col-xs-4 col-sm-4 col-md-3">
                                                <div class="c-lista-produto-linha-item-img">
                                                    <img src="assets/images/produto/prod-3.png"
                                                         alt="IPlug Industrial 3p 32a 220v 6h 3276 Azul">
                                                </div>
                                            </div>

                                            <div class="col-xs-8 col-sm-8 col-md-9">
                                                <div class="c-lista-produto-linha-item-conteudo">
                                                    <h2 class="c-lista-produto-linha-item-titulo h4">IPlug Industrial 3p
                                                        32a 220v 6h 3276 Azul</h2>
                                                    <div class="c-lista-produto-linha-item-fabricante-img">
                                                        <img src="assets/images/fabricante/philips-2.png"
                                                             alt="Philips">
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div> <!-- Fim item listagem em linha -->

                                    <!-- Item listagem em linha -->
                                    <div class="c-lista-produto-linha-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto" style="width: 100%;">
                                            <div class="col-xs-4 col-sm-4 col-md-3">
                                                <div class="c-lista-produto-linha-item-img">
                                                    <img src="assets/images/produto/lampada-philips-2.png"
                                                         alt="Philips Led. Equiv. 75w, branco quente suave">
                                                </div>
                                            </div>

                                            <div class="col-xs-8 col-sm-8 col-md-9">
                                                <div class="c-lista-produto-linha-item-conteudo">
                                                    <h2 class="c-lista-produto-linha-item-titulo h4">Philips Led. Equiv.
                                                        75w, branco quente suave</h2>
                                                    <div class="c-lista-produto-linha-item-fabricante-img">
                                                        <img src="assets/images/fabricante/brilia-2.png"
                                                             alt="Philips">
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div> <!-- Fim item listagem em linha -->

                                    <!-- Item listagem em linha -->
                                    <div class="c-lista-produto-linha-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto" style="width: 100%;">
                                            <div class="col-xs-4 col-sm-4 col-md-3">
                                                <div class="c-lista-produto-linha-item-img">
                                                    <img src="assets/images/produto/prod-1.png"
                                                         alt="Interruptor Fuga Dr C/2 Polos 125a 30ma - Steck">
                                                </div>
                                            </div>

                                            <div class="col-xs-8 col-sm-8 col-md-9">
                                                <div class="c-lista-produto-linha-item-conteudo">
                                                    <h2 class="c-lista-produto-linha-item-titulo h4">Interruptor Fuga Dr
                                                        C/2 Polos
                                                        125a 30ma - Steck</h2>
                                                    <div class="c-lista-produto-linha-item-fabricante-img">
                                                        <img src="assets/images/fabricante/galaxy-2.png"
                                                             alt="Philips">
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div> <!-- Fim item listagem em linha -->
                                </div>
                            </div>
                        </div>
                        <div class="c-paginacao">
                            <div class="pagination" style="position: relative">
                                <a href='#' class="c-paginacao-item c-paginacao-item-ativo">1</a>
                                <a href='#' class="c-paginacao-item">2</a>
                                <a href='#' class="c-paginacao-item">3</a>
                                <a href='#' class="c-paginacao-item">4</a>
                                <a href="#" class="c-paginacao-item c-paginacao-item-txt">Próximo</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pull-left col-xs-12 col-sm-4 col-md-3">
                    <div class="sidebar">

                        <div class="sidebar-topo">
                            <h1 class="h3">Materiais Elétricos</h1>
                            <p>1.500 resultados</p>
                        </div>

                        <div class="sidebar-item sidebar-item-ordenacao">
                            <h2 class="h4">Ordenação</h2>

                            <div class="form-group">
                                <select class="form-control" id="select-ordenacao">
                                    <option value="Relevancia">Relevância</option>
                                    <option value="mais-visitados">Mais visitados</option>
                                    <option value="ordem-alfabetica">Order alfabética</option>
                                </select>
                                <a href="categoria-produto-visao-linha.php" title="Ver itens em colunas"><img
                                            class="icone-coluna-ordenacao"
                                            src="assets/images/icones/icon-coluna-ativo.svg"></a>
                                <a href="categoria-produto.php" title="Ver itens em linhas"><img
                                            class="icone-grid-ordenacao" src="assets/images/icones/icon-grid-inativo.svg"></a>
                            </div>

                            <a class="btn btn-link" title="Limpar filtros de atributos">Limpar filtros de atributos <a
                                        href="#" title="Limpar filtros atribuidos"><img class="icone-limpar-filtro"
                                                                                        src="assets/images/icones/icon-limpar.svg"></a></a>
                        </div>

                        <div class="sidebar-item">
                            <h2 class="h4">Tipos de Pólos</h2>
                            <ul class="list-unstyled">
                                <li><a href="categoria-produto.php">Tetrapolar</a></li>
                                <li><a href="categoria-produto.php">Bipolar</a></li>
                            </ul>
                            <a class="btn btn-link" title="Ver todos">Ver todos</a>
                        </div>

                        <div class="sidebar-item">
                            <h2 class="h4">Miliampéres</h2>
                            <ul class="list-unstyled">
                                <li><a href="categoria-produto.php">300 mA <span>(190)</span></a></li>
                                <li><a href="categoria-produto.php">300 mA <span>(785)</span></a></li>
                            </ul>
                            <a class="btn btn-link" title="Ver todos">Ver todos</a>
                        </div>

                        <div class="sidebar-item">
                            <h2 class="h4">Cor</h2>
                            <ul class="list-unstyled">
                                <li><a href="categoria-produto.php">Azul <span>(190)</span></a></li>
                                <li><a href="categoria-produto.php">Vermelho<span>(785)</span></a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <h2 class="h4">Cidade</h2>
                            <ul class="list-unstyled">
                                <li><a href="categoria-produto.php">São Paulo <span>(190)</span></li>
                                <li><a href="categoria-produto.php">Curitiba<span>(785)</span></li>
                                <li><a href="categoria-produto.php">Rio de Janeiro<span>(123)</span></li>
                                <li><a href="categoria-produto.php">Santa Catarina<span>(89)</span></li>
                            </ul>
                            <a class="btn btn-link" title="Ver todos">Ver todos</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Modal Marcas -->

    <div class="modal fade" id="modalTodasMarcas" tabindex="-1" role="dialog" aria-labelledby="modalTodasMarcasLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <!--                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
                    <h4 class="modal-title" id="modalTodasMarcasLabel">Confira todos os fabricantes de produtos dessa categoria</h4>
                </div>
                <div class="modal-body">
                    <div class="c-listagem-marca c-listagem-marca-modal">
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <div class="row">
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/brilia-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/galaxy-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/ourolux-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/philips-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/ge-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/brilia-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="#" class="c-listagem-marca-item">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/brilia-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/galaxy-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/ourolux-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/philips-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/ge-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/brilia-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/brilia-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/galaxy-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/ourolux-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/philips-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/ge-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 col-sm-2 col-md-2 c-listagem-marca-modal-item">
                                        <a href="categoria-produto.php" class="c-listagem-marca-item"
                                           title="Veja os produtos dessa marca">
                                            <div class="c-listagem-marca-item-img">
                                                <img src="assets/images/fabricante/brilia-2.png"
                                                     alt="Conheça os produtos dessa marca">
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Fim Modal Marcas -->


    <!-- Produtos sugeridos -->
    <section class="s-padrao s-produto-sugerido">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Produtos sugeridos para você nesta categoria:</h2>
                </div>
                <div class="slide-produto slide-produto-default">
                    <div class="MultiCarousel" data-items="2,3,4,4" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ourolux-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ge-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/brilia-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>


                        </div>
                        <button class="btn btn-primary btn-arrow leftLst"><</button>
                        <button class="btn btn-primary btn-arrow rightLst">></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Fim Produtos sugeridos -->

    <!-- Categorias visitadas -->
    <section class="s-padrao s-quem-visitou-categoria">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Quem visitou esta categoria também viu estes produtos:</h2>
                </div>
                <div class="slide-produto slide-produto-small">
                    <div class="MultiCarousel" data-items="2,3,5,6" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <div class="b-slide-produto-item-img">
                                                <img src="assets/images/produtos/quem-visitou/cabos-e-fios-1.png" alt=""
                                                     class="slide-produto-item-img">
                                            </div>
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Cabos e fios
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/componentes-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Componentes Elétricos
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/eletroduto-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Eletroduto
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/extensoes-filtros-1.png"
                                                 alt="" class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Extensões e filtros de linha
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/interruptor-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Interruptor
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/seguranca-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Segurança elétrica
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <div class="b-slide-produto-item-img">
                                                <img src="assets/images/produtos/quem-visitou/cabos-e-fios-1.png" alt=""
                                                     class="slide-produto-item-img">
                                            </div>
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Cabos e fios
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/componentes-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Componentes Elétricos
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/eletroduto-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Eletroduto
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/extensoes-filtros-1.png"
                                                 alt="" class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Extensões e filtros de linha
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/interruptor-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Interruptor
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/seguranca-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Segurança elétrica
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-arrow leftLst">
                            <
                        </button>
                        <button class="btn btn-primary btn-arrow rightLst">>
                        </button>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <a class="btn btn-default btn-lg" href="#">Ver todas as categorias</a>
                </div>

            </div>
        </div>
    </section>
    <!-- Fim Categorias visitadas -->

    <section class="s-cta-pattern">
        <div class="bg-homem">
            <div class="s-padrao">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-8 col-md-6">
                            <h2 class="titulo-secao">Use a plataforma Cataloteca como sua base de produtos
                                atualizada!</h2>
                            <p>Sua empresa pode fazer o upload de seus produtos na plataforma e teremos uma inteligência
                                artificial trabalhando para completar a maior quantidade possível de dados técnicos.</p>
                            <a class="btn btn-default btn-lg" href="#">Acessar Cataloteca como base de produtos</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>