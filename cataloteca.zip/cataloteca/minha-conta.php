<div class="pg-minha-conta">
    <?php
    $pg = 'minha-conta';
    $titulo = 'Visão geral da sua conta';
    $description = 'Visão geral da sua conta';
    include('head.php');
    include('menu-pesquisa-minha-conta.php');
    include('menu-categoria.php');
    ?>

    <section class="s-padrao s-minha-conta" style="padding-top: 3em;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-9 pull-right">
                    <div class="s-minha-conta-conteudo">
                        <h2 class="h3 titulo-minha-conta">Olá, Bruno Magalhães</h2>
                        <p class="descricao-minha-conta">Acompanhe abaixo suas últimas atividades</p>

                        <div class="s-minha-conta-conteudo-box">
                            <!-- item minha conta -->
                            <div class="minha-conta-item">
                                <div class="s-minha-conta-listagem">
                                    <h2 class="h3 pull-left">Últimas listas adicionadas</h2>
                                    <div class="clearfix"></div>


                                    <div class="row">
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="minha-conta-lista-produto-detalhe.php"
                                                                  title="Lâmpadas para corredor">Lâmpadas para
                                                        corredor </a></h2>

                                                <p><a href="#" title="23 produtos adicionados nessa lista">23
                                                        produtos</a>
                                                    adicionados nessa lista</p>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="minha-conta-lista-produto-detalhe.php"
                                                                  title="Geradores">Geradores</a></h2>
                                                <p><a href="categoria-produto.php"
                                                      title="2 produtos adicionados nessa lista">2 produtos</a>
                                                    adicionados nessa lista</p>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="minha-conta-lista-produto-detalhe.php"
                                                                  title="Geradores">Geradores</a></h2>
                                                <p><a href="categoria-produto.php"
                                                      title="2 produtos adicionados nessa lista">2 produtos</a>
                                                    adicionados nessa lista</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- fim item minha conta -->

                            <!-- item minha conta -->
                            <div class="minha-conta-item">
                                <div class="s-minha-conta-listagem">
                                    <h2 class="h3 pull-left">Últimas contribuições</h2>

                                    <div class="clearfix"></div>


                                    <div class="row">
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="minha-conta-lista-produto-detalhe.php"
                                                                  title="Lâmpadas para corredor">Contribuição 01 </a>
                                                </h2>

                                                <p><a href="#" title="23 produtos adicionados nessa lista">23
                                                        produtos</a>
                                                    adicionados nessa lista</p>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="minha-conta-lista-produto-detalhe.php"
                                                                  title="Geradores">Contribuição 02</a></h2>
                                                <p><a href="categoria-produto.php"
                                                      title="2 produtos adicionados nessa lista">2 produtos</a>
                                                    adicionados nessa lista</p>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="minha-conta-lista-produto-detalhe.php"
                                                                  title="Geradores">Contribuição 03</a></h2>
                                                <p><a href="categoria-produto.php"
                                                      title="2 produtos adicionados nessa lista">2 produtos</a>
                                                    adicionados nessa lista</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- fim item minha conta -->

                            <!-- item minha conta -->
                            <div class="minha-conta-item">
                                <div class="s-minha-conta-listagem">
                                    <h2 class="h3 pull-left">Últimas categorias visitadas</h2>

                                    <div class="clearfix"></div>


                                    <div class="row">
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="categoria-produto-logado.php"
                                                                  title="Lâmpadas para corredor">Lâmpadas</a>
                                                </h2>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="categoria-produto-logado.php"
                                                                  title="Geradores">Cabos</a></h2>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                            <div class="s-minha-conta-listagem-item">
                                                <h2 class="h4"><a href="categoria-produto-logado.php"
                                                                  title="Geradores">Ferramentas</a></h2>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- fim item minha conta -->

                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-4 col-md-3 pull-left">
                    <div class="sidebar sidebar-minha-conta">
                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-minha-conta.svg">
                            <h2 class="h4">Minha conta</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-editar-dados-pessoais.php" class="active">Últimas atividades</a></li>
                                <li><a href="minha-conta-editar-dados-pessoais.php">Editar meus dados</a></li>
                                <li><a href="minha-conta-editar-dados-empresa.php">Editar dados da empresa</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-lista-produto.svg">
                            <h2 class="h4">Listas de produtos</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-lista-produto.php" title="Minhas listas">Minhas
                                        listas</a></li>
                                <li><a href="javascrip:void(0);" title="Criar nova lista">Criar nova lista</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda"
                                 src="assets/images/icones/icon-lista-contribuicao.svg">
                            <h2 class="h4">Listas de contribuições</h2>

                            <ul class="list-unstyled">
                                <li><a href="javascrip:void(0);" title="Minhas contribuições">Minhas contribuições</a></li>
                                <li><a href="javascrip:void(0);" title="Submeter sugestões">Submeter sugestões</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>
