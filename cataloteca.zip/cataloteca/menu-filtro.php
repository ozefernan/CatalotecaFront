<!-- Header -->
<header>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <nav class="navbar navbar-default menu-filtro hidden-xs">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#menu-dropdown" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <a class="navbar-brand pull-left visible-xs" href="#">Menu</a>

                    <div class="menu-todas-categorias hidden-xs">
                        <ul class="c-mega-menu-categorias nav navbar-nav">
                            <li class="mega-dropdown"> <!-- Esse LI é o equivalente ao .dropdown -->
                                <a>
                                    Todas as categorias
                                </a>
                                <ul class="mega-dropdown-menu">  <!-- Esse UL é o equivalente ao .dropdown-menu -->
                                    <li>
                                        <a href="categoria-produto.php">
                                            Materiais Elétricos <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Materiais Elétricos" href="categoria-produto.php">Materiais Elétricos</a></h2>
                                                        </div>

                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Interruptor e tomada" href="categoria-produto.php">Interruptor e tomada</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Disjuntor e Caixas" href="categoria-produto.php">Disjuntor e Caixas</a></li>
                                                                    <li><a title="Tomada" href="categoria-produto.php">Tomada</a></li>
                                                                    <li><a title="Placas e Conjunto" href="categoria-produto.php">Placas e Conjuntos</a></li>
                                                                    <li><a title="Campainhas" href="categoria-produto.php">Campainhas</a></li>
                                                                    <li><a title="Interruptor" href="categoria-produto.php">Interruptor</a></li>
                                                                </ul>

                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->

                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Cabos e Fios" href="categoria-produto.php">Cabos e Fios</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Organização de cabos" href="categoria-produto.php">Organização de cabos</a></li>
                                                                    <li><a title="Eletroduto" href="categoria-produto.php">Eletroduto</a></li>
                                                                    <li><a title="Cabo PP" href="categoria-produto.php">Cabo PP</a></li>
                                                                    <li><a title="Condulete" href="categoria-produto.php">Condulete</a></li>
                                                                    <li><a title="Cabos Flexíveis 750v" href="categoria-produto.php">Cabos Flexíveis 750v</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->

                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Instalação Elétrica" href="categoria-produto.php">Segurança Elétrica</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Sensores" href="categoria-produto.php">Sensores</a></li>
                                                                    <li><a title="Iluminação de Emergência" href="categoria-produto.php">Iluminação de Emergência</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->

                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Iluminação" href="categoria-produto.php">Iluminação</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Luminárias" href="categoria-produto.php">Luminárias</a></li>
                                                                    <li><a title="Soquete" href="categoria-produto.php">Soquete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->

                                                        <div class="clearfix"></div>

                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Instalação Elétrica" href="categoria-produto.php">Instalação Elétrica</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Terminais" href="categoria-produto.php">Cabo Flexível 1KVA</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Fitas Isolantes</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Extensões e Filtros de Linha</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Terminais</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Disjuntores</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Quadros e Caixas Elétricas</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Cintadores e Reles</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->


                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Componentes Elétricos" href="categoria-produto.php">Componentes Elétricos</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Resistência" href="categoria-produto.php">Resistência</a></li>
                                                                    <li><a title="Conectores" href="categoria-produto.php">Conectores</a></li>
                                                                    <li><a title="Conduítes" href="categoria-produto.php">Conduítes</a></li>
                                                                    <li><a title="Terminais" href="categoria-produto.php">Terminais</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->

                                                        <!--Item -->
                                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                            <div class="listagem-todas-categorias-item">
                                                                <h2 class="h4"><a title="Sensores" href="categoria-produto.php">Acessórios de componentes</a></h2>

                                                                <ul class="list-unstyled listagem-todas-categorias-lista">
                                                                    <li><a title="Fitas Isolantes" href="categoria-produto.php">Fitas Isolantes</a></li>
                                                                    <li><a title="Iluminação de Emergência" href="categoria-produto.php">Iluminação de Emergência</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!--Fim Item -->
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>

                                    </li>

                                    <li>
                                        <a href="categoria-produto.php">
                                            EPI e EPC <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="EPI e EPC" href="categoria-produto.php">EPI e EPC</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Higiene e Limpeza <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Higiene e Limpeza" href="categoria-produto.php">Higiene e Limpeza</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Escritório <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Escritório" href="categoria-produto.php">Escritório</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Food Service e Restaurantes <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Food Service e Restaurantes" href="categoria-produto.php">Food Service e Restaurantes</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Fixação <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Fixação" href="categoria-produto.php">Fixação</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Embalagens <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Embalagens" href="categoria-produto.php">Embalagens</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Ferramentas <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Ferramentas" href="categoria-produto.php">Ferramentas</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Solda e Corte <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Solda e Corte" href="categoria-produto.php">Solda e Corte</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Manutenção <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Manutenção" href="categoria-produto.php">Manutenção</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Informática <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Informática" href="categoria-produto.php">Informática</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Movimentação e Elevação <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Movimentação e Elevação" href="categoria-produto.php">Movimentação e Elevação</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="categoria-produto.php">
                                            Abrasivo <i class="fas fa-chevron-right pull-right"></i>
                                        </a>

                                        <div class="mega-dropdown-submenu">

                                            <div class="mega-dropdown-submenu-content">

                                                <div class="listagem-todas-categorias-box">

                                                    <div class="row listagem-todas-categorias-item-categoria">
                                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <h2 class="h3"><a title="Abrasivo" href="categoria-produto.php">Abrasivo</a></h2>
                                                        </div>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>

                                    <li role="separator" class="divider"></li>

                                    <li>
                                        <a href="todas-categorias.php">Todas as categorias</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                    <div class="collapse navbar-collapse" id="menu-dropdown">
                        <ul class="nav navbar-nav navbar-right menu-filtro-listagem-itens">
                            <li>Filtrado por:</li>
                            <li><a href="#" title="Cabos">Cabos</a></li>
                            <li><a href="#" title="Ferramentas">Ferramentas</a></li>
                            <li><a href="#" title="Disjuntores">Disjuntores</a></li>
                        </ul>
                    </div>
                </nav>

                <nav class="navbar navbar-default visible-xs">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#menu-dropdown-mobile" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div class="menu-todas-categorias">
                        <ul class="nav navbar-nav">
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                   aria-haspopup="true" aria-expanded="false">Categorias<span
                                            class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="categoria-produto.php">Materiais Elétricos <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">EPI e EPC <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Higiene e Limpeza <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Escritório <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Food Service e Restaurantes <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Fixação <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Embalagens <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Ferramentas <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Solda e Corte <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Manutenção <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Informática <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Movimentação e Elevação <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li><a href="categoria-produto.php">Abrasivo <i
                                                    class="fas fa-chevron-right pull-right"></i></a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="todas-categorias.php">Todas as categorias</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                    <div class="collapse navbar-collapse" id="menu-dropdown-mobile">
                        <ul class="nav navbar-nav navbar-right menu-filtro-listagem-itens">
                            <li><a href="index.php" title="Início">Início</a></li>
                            <li><a href="categoria-produto.php" title="Produtos">Produtos</a></li>
                            <li><a href="contato.php" title="Fale conosco">Contato</a></li>
                            <li style="height: 1px; background: #fff;"></li>
                            <li><a href="login.php" title="Login">Login</a></li>
                            <li><a href="cadastro.php" title="Cadastro">Cadastro</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <!--filtros aplicados mobile -->
    <div class="menu-filtro-mobile border-top visible-xs">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <ul class="menu-filtro-listagem-itens list-inline list-unstyled">
                        <li>Filtrado por:</li>
                        <li><a href="#" title="Cabos">Cabos</a></li>
                        <li><a href="#" title="Ferramentas">Ferramentas</a></li>
                        <li><a href="#" title="Disjuntores">Disjuntores</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</header>
<!-- Header -->