(function(){
    'use strict';
	/*global require */

    var gulp = require('gulp');
    var sass = require('gulp-sass');
    var sourcemaps = require('gulp-sourcemaps');
    var uglify = require('gulp-uglify');
    var rename = require('gulp-rename');
    var minifycss = require('gulp-minify-css');
    var concat = require('gulp-concat');
    var plumber = require('gulp-plumber');
    var browserSync = require('browser-sync');

    var reload = browserSync.reload;
// setting folder templates

    var  themeDir = '../';
    var  dirs = {
        css: themeDir+'/assets/css',
        js: themeDir+'/assets/js',
        sass:  themeDir+'/assets/sass',
        images:  themeDir+'/assets/images',
        fonts:  themeDir+'/assets/fonts',
        tmp: 'tmp'
    };

	/* Scripts uglify task */
    gulp.task('uglify', function() {
        return gulp.src([
			/* Add your JS files here, they will be combined in this order */
            dirs.js+'/libs/*.js',
            dirs.js+'/custom.js'
        ])
            .pipe(concat('main.js'))
            .pipe(rename({suffix: '.min'}))
            .pipe(uglify())
            .pipe(gulp.dest(dirs.js));
    });

	/* Scripts uglify task */
    gulp.task('uglify-bootstrap', function() {
        return gulp.src([
			/* Add your JS files here, they will be combined in this order */
            dirs.js +'/bootstrap/transition.js',
            dirs.js +'/bootstrap/alert.js',
            dirs.js +'/bootstrap/button.js',
            dirs.js +'/bootstrap/carousel.js',
            dirs.js +'/bootstrap/collapse.js',
            dirs.js +'/bootstrap/dropdown.js',
            dirs.js +'/bootstrap/modal.js',
            dirs.js +'/bootstrap/tooltip.js',
            dirs.js +'/bootstrap/popover.js',
            dirs.js +'/bootstrap/scrollspy.js',
            dirs.js +'/bootstrap/tab.js',
            dirs.js +'/bootstrap/affix.js'
        ])
            .pipe(concat('bootstrap.js'))
            .pipe(rename({suffix: '.min'}))
            .pipe(uglify())
            .pipe(gulp.dest(dirs.js+'/libs/'));
    });

	/* Sass task */
    gulp.task('sass', function () {
        gulp.src(dirs.sass+'/*.scss')
            .pipe(plumber())
            .pipe(sass({
                outputStyle: 'compressed',
                sourceComments: 'map',
                includePaths: [dirs.sass]
            }))
            .pipe(minifycss())
            .pipe(gulp.dest(dirs.css))

			/* Reload the browser CSS after every change */
            .pipe(reload({stream:true}));
    });

	/* Sass task */
    gulp.task('sass-sourcemap', function () {
        gulp.src(dirs.sass+'/*.scss')
            .pipe(plumber())
            .pipe(sourcemaps.init({loadMaps: true}))
            .pipe(sass({
                outputStyle: 'compressed',
                sourceComments: 'map',
                includePaths: [dirs.sass]
            }))
            .pipe(sourcemaps.write('.',{includeContent: true, sourceRoot: dirs.css}))
            .pipe(gulp.dest(dirs.css));
    });

	/* Reload task */
    gulp.task('bs-reload', function () {
        browserSync.reload();
    });

	/* Prepare Browser-sync for localhost */
    gulp.task('browser-sync', function() {
        browserSync.init(['css/*.css', 'js/*.js'], {
			/*
			 I like to use a vhost, WAMP guide: https://www.kristengrote.com/blog/articles/how-to-set-up-virtual-hosts-using-wamp, XAMP guide: http://sawmac.com/xampp/virtualhosts/
			 */
            proxy: 'nano.incub'
			/* For a static server you would use this: */
			/*
			 server: {
			 baseDir: './'
			 }
			 */
        });
    });

	/* Watch scss, js and html files, doing different things with each. */
    gulp.task('default', ['sass', 'browser-sync'], function () {

        gulp.watch([dirs.sass+'/*.scss', dirs.sass+'/**/*.scss'], ['sass','sass-sourcemap']);

        gulp.watch([dirs.js+'/main.js',dirs.js+'/libs/*.js','gulpfile.js'], ['uglify']);

        gulp.watch([dirs.js +'/bootstrap/*.js'], ['uglify-bootstrap']);

        gulp.watch([themeDir+'/*.php',themeDir+'/**/*.php'], ['bs-reload']);

    });

})();