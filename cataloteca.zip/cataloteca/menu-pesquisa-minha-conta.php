<!-- Menu pesquisa -->
<div class="c-menu-pesquisa">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-3 col-md-3">
                <div class="logo">
                    <a href="categoria-produto-logado.php" title="Cataloteca"><img class="img-logo" src="assets/images/cataloteca-logo.svg"
                                                                alt="Cataloteca"> </a>
                </div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-6">
                <form class="form-inline" method="get" action="categoria-produto.php">
                    <input class="form-control" type="text"
                           placeholder="Pesquise por produtos, marca ou característica..." aria-label="Search">
                    <button class="btn btn-search-form" type="submit"><img src="assets/images/icones/icon-search.svg">
                    </button>
                </form>
            </div>

            <div class="col-xs-12 col-sm-3 col-md-3">
                <div class="c-menu-pesquisa-s-minha-conta">
                    <p class="">Olá,</p>
                    <div class="c-menu-pesquisa-s-minha-conta-dropdown">
                        <a class="btn btn-link dropdown-toggle" type="button" data-toggle="dropdown">Bruno
                            <img src="assets/images/icones/caret-dropdown.svg"></a>
                        <ul class="dropdown-menu">
                            <li><a href="minha-conta.php">Minha conta</a></li>
                            <li><a href="minha-conta-lista-produto.php">Listas de produtos</a></li>
                            <li><a href="#">Listas de contribuições</a></li>
                            <li><a href="index.php">Sair</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!--/ Menu pesuisa -->