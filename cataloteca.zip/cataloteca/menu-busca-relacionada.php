<div class="s-menu-busca-relacionada border-bottom">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <ul class="menu-busca-relacionada list-inline">
                    <li>Buscas relacionadas: </li>
                    <li><a href="categoria-produto.php" title="Geradores Elétricos">Geradores Elétricos</a></li>
                    <li><a href="categoria-produto.php" title="Proteção Elétrica">Proteção Elétrica</a></li>
                    <li><a href="categoria-produto.php" title="Medidores Elétricos">Medidores Elétricos</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>