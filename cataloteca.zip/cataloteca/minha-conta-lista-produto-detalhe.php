<div class="pg-minha-conta-produto-detalhe">
    <?php
    $pg = 'categoria-produyto';
    $titulo = 'Categoria do produto';
    $description = 'Encontre produtos de uma categoria específica';
    include('head.php');
    include('menu-pesquisa-minha-conta.php');
    include('menu-categoria.php');
    ?>

    <section class="s-padrao s-minha-conta" style="padding-top: 3em;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-9 pull-right">
                    <div class="s-minha-conta-conteudo">
                        <div class="s-minha-conta-conteudo-topo">
                            <h2 class="h3 pull-left">Produtos para lista: "Lâmpadas para corredor"</h2>
                            <a class="pull-right link-download" href="#" title="Download arquivo com produtos"><img
                                        class="icone-download" src="assets/images/icones/icon-download.svg"> Download
                                arquivo com produtos</a>
                            <div class="clearfix"></div>
                            <p><a href="categoria-produto-logado.php" title="23 produtos adicionados nessa lista">23 produtos</a>
                                adicionados nessa lista</p>
                            <p>Produtos da categoria <a href="categoria-produto-logado.php" title="Lâmpadas">lâmpadas</a>, <a
                                        href="categoria-produto-logado.php" title="Soquetes">soquetes</a> e <a href="categoria-produto-logado.php"
                                                                                    title="Fios">fios</a>
                                e <a href="categoria-produto-logado.php" title="Cabos">cabos</a>.</p>
                        </div>


                        <!--Listagem de produtos -->
                        <div class="c-lista-produto">
                            <div class="row">
                                <div class="col-xs-6 col-sm-4 col-md-4">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-1.png"
                                                     alt="Interruptor Fuga Dr C/2 Polos 125a 30ma - Steck">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos
                                                125a 30ma - Steck</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-4">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-1.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos
                                                125a 30ma - Steck</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-4">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-3.png"
                                                     alt="IPlug Industrial 3p 32a 220v 6h 3276 Azul">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">IPlug Industrial 3p 32a 220v 6h
                                                3276 Azul</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-4">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/lampada-philips-2.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Philips Led. Equiv. 75x branco
                                                quente suave</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-4">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/lampada-philips-2.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Philips Led. Equiv. 75x branco
                                                quente suave</h2>
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!--Fim Listagem de produtos -->
                    </div>
                </div>

                <div class="col-xs-12 col-sm-4 col-md-3 pull-left">
                    <div class="sidebar sidebar-minha-conta">
                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-minha-conta.svg">
                            <h2 class="h4">Minha conta</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-editar-dados-pessoais.php">Últimas atividades</a></li>
                                <li><a href="minha-conta-editar-dados-pessoais.php">Editar meus dados</a></li>
                                <li><a href="minha-conta-editar-dados-empresa.php">Editar dados da empresa</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-lista-produto.svg">
                            <h2 class="h4">Listas de produtos</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-lista-produto.php" class="active" title="Minhas listas">Minhas listas</a></li>
                                <li><a href="javascrip:void(0);" title="Criar nova lista">Criar nova lista</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda"
                                 src="assets/images/icones/icon-lista-contribuicao.svg">
                            <h2 class="h4">Listas de contribuições</h2>

                            <ul class="list-unstyled">
                                <li><a href="javascrip:void(0);" title="Minhas contribuições">Minhas contribuições</a></li>
                                <li><a href="javascrip:void(0);" title="Submeter sugestões">Submeter sugestões</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>
