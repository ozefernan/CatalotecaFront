<div class="pg-minha-conta-editar-dados-pessoais">
    <?php
    $pg = 'minha-conta-editar-dados-pessoais';
    $titulo = 'Edite os seus dados pessoais';
    $description = 'Edite os seus dados pessoais';
    include('head.php');
    include('menu-pesquisa-minha-conta.php');
    include('menu-categoria.php');
    ?>

    <section class="s-padrao s-minha-conta" style="padding-top: 3em;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-9 pull-right">
                    <div class="s-minha-conta-conteudo">
                        <h2 class="h3">Editar dados pessoais</h2>

                        <div class="s-minha-conta-conteudo-box">

                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <!--Formulário de edição de dados pessoais -->
                                    <div class="s-minha-conta-formulario">
                                        <h3 class="h4">Dados atuais</h3>
                                        <form class="form form-minha-conta">
                                            <div class="form-group">
                                                <label for="lb_nome_pessoa">Nome</label>
                                                <input type="text" class="form-control" id="lb_nome_pessoa"
                                                       value="Bruno Magalhães">
                                            </div>

                                            <div class="form-group">
                                                <label for="lb_email">E-mail</label>
                                                <input type="email" class="form-control" id="lb_email"
                                                       value="brunomagalhaes@brunomagalhaes.com.br">
                                            </div>

                                            <div class="form-group">
                                                <label for="lb_tel_pessoa">Telefone</label>
                                                <input type="tel" class="form-control" id="lb_tel_pessoa"
                                                       value="(19) 9 9292-9897">
                                            </div>

                                            <div class="form-group">
                                                <label for="lb_cpf_pessoa">CPF</label>
                                                <input type="text" class="form-control" id="lb_cpf_pessoa"
                                                       value="406.588.741-65">
                                            </div>

                                            <!--                                            <button type="submit" class="btn btn-default btn-lg btn-block">Entrar-->
                                            <!--                                            </button>-->
                                            <a class="btn btn-default btn-lg" href="minha-conta-lista-produto.php">Salvar
                                                alterações</a>
                                        </form>
                                    </div>
                                    <!-- Fim Formulário de edição de dados pessoais -->
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-5 col-xs-offset-0 col-sm-offset-0 col-md-offset-1">
                                    <h3 class="h4 titulo-alterar-senha">Alterar minha senha</h3>

                                    <form class="form-minha-conta" action="">
                                        <div class="form-group">
                                            <label for="lb_senha">Senha atual</label>
                                            <input type="password" class="form-control" id="lb_senha"
                                                   placeholder="Senha atual">
                                        </div>
                                        <div class="form-group">
                                            <label for="lb_senha">Nova senha</label>
                                            <input type="password" class="form-control" id="lb_senha"
                                                   placeholder="Nova senha">
                                        </div>
                                        <div class="form-group">
                                            <label for="lb_senha">Repetir nova senha</label>
                                            <input type="password" class="form-control" id="lb_senha"
                                                   placeholder="Repetir nova senha">
                                        </div>

                                        <!--                                            <button type="submit" class="btn btn-default btn-lg btn-block">Entrar-->
                                        <!--                                            </button>-->
                                        <a class="btn btn-default btn-lg" href="javascrip:void(0);">Salvar senha</a>

                                    </form>

                                </div>


                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-4 col-md-3 pull-left">
                    <div class="sidebar sidebar-minha-conta">
                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-minha-conta.svg">
                            <h2 class="h4">Minha conta</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-editar-dados-pessoais.php">Últimas atividades</a></li>
                                <li><a class="active" href="minha-conta-editar-dados-pessoais.php">Editar meus dados</a>
                                </li>
                                <li><a href="minha-conta-editar-dados-empresa.php">Editar dados da empresa</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-lista-produto.svg">
                            <h2 class="h4">Listas de produtos</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-lista-produto.php" title="Minhas listas">Minhas listas</a></li>
                                <li><a href="#" title="Criar nova lista">Criar nova lista</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda"
                                 src="assets/images/icones/icon-lista-contribuicao.svg">
                            <h2 class="h4">Listas de contribuições</h2>

                            <ul class="list-unstyled">
                                <li><a href="#" title="Minhas contribuições">Minhas contribuições</a></li>
                                <li><a href="categoria-produto.php" title="Submeter sugestões">Submeter sugestões</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>