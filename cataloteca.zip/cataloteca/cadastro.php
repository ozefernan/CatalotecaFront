<div class="pg-login">
    <?php
    $pg = 'cadastro';
    $titulo = 'Cadastre-se no Cataloteca';
    $description = 'Efetue cadastro no sistema para acessar sua base de itens saneados.';
    include('head.php');
    include('menu-pesquisa.php');
    include('menu-categoria.php');
    ?>

    <section class="s-login">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="item-mro">
                        <div class="s-padrao">
                            <div class="row">
                                <div class="col-md-10">
                                    <div class="item-distribuidor text-center">
                                        <div class="row">
                                            <div class="col-md-10 col-md-offset-1">

                                                <h2 class="h3">É um comprador MRO?</h2>
                                                <p>Lorem ipsum dolor sit amet, sapien etiam, nunc amet dolor ac odio
                                                    mauris
                                                    justo.</p>

                                                <div class="item-distribuidor-b-conteudo">

                                                    <a class="btn btn-lg btn-default"
                                                       href="cadastro-mro.php">Cadastre-se</a>

                                                    <div class="b-item-distribuidor-cadastre-se">
                                                        <p class="traco-texto">ou</p>

                                                        <h4 class="h4">Já tenho meu cadastro</h4>
                                                        <a class="btn btn-default btn-outline btn-lg" href="login.php">Efetuar login</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 bg-xs">
                    <div class="item-distribuidor text-center">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="s-padrao">
                                    <h2 class="h3">É um fabricante ou distribuidor?</h2>
                                    <p>Lorem ipsum dolor sit amet, sapien etiam, nunc amet dolor ac odio mauris
                                        justo.</p>

                                    <div class="item-distribuidor-b-conteudo">

                                        <a class="btn btn-lg btn-default" href="#">Cadastre-se</a>

                                        <div class="b-item-distribuidor-cadastre-se">
                                            <p class="traco-texto">ou</p>

                                            <h4 class="h4">Já tenho meu cadastro</h4>
                                            <a class="btn btn-default btn-outline btn-lg" href="login.php">Efetuar login</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include('footer.php'); ?>
</div>
