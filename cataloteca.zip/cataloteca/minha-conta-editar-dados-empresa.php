<div class="pg-minha-conta-editar-dados-empresa">
    <?php
    $pg = 'minha-conta-editar-dados-empresa';
    $titulo = 'Edite os dados da sua empresa';
    $description = 'Edite os seus dados pessoais';
    include('head.php');
    include('menu-pesquisa-minha-conta.php');
    include('menu-filtro.php');
    include('menu-busca-relacionada.php');
    ?>

    <section class="s-padrao s-minha-conta" style="padding-top: 3em;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-9 pull-right">
                    <div class="s-minha-conta-conteudo">
                        <h2 class="h3">Editar dados da empresa</h2>

                        <div class="s-minha-conta-conteudo-box">


                            <!--Formulário de edição de dados pessoais -->
                            <div class="s-minha-conta-formulario">
                                <h3 class="h4">Dados atuais</h3>
                                <form class="form form-minha-conta">
                                    <div class="form-group">
                                        <label for="lb_nome_pessoa">Razão Social</label>
                                        <input type="text" class="form-control" id="lb_nome_empresa"
                                               value="Cataloteca SA">
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_email">E-mail</label>
                                        <input type="email" class="form-control" id="lb_email"
                                               value="empresa@empresa.com.br">
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_tel_empresa">Telefone</label>
                                        <input type="tel" class="form-control" id="lb_tel_empresa"
                                               value="(19) 3232-3232">
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_cpf_pessoa">CNPJ</label>
                                        <input type="text" class="form-control" id="lb_cnpj_empresa"
                                               value="12.123.123/1234-12">
                                    </div>

                                    <!--                                            <button type="submit" class="btn btn-default btn-lg btn-block">Entrar-->
                                    <!--                                            </button>-->
                                    <a class="btn btn-default btn-lg" href="minha-conta-lista-produto.php">Salvar
                                        alterações</a>
                                </form>
                            </div>
                            <!-- Fim Formulário de edição de dados pessoais -->
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-4 col-md-3 pull-left">
                    <div class="sidebar sidebar-minha-conta">
                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-minha-conta.svg">
                            <h2 class="h4">Minha conta</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-editar-dados-pessoais.php">Últimas atividades</a></li>
                                <li><a href="minha-conta-editar-dados-pessoais.php">Editar meus dados</a>
                                </li>
                                <li><a class="active" href="minha-conta-editar-dados-empresa.php">Editar dados da
                                        empresa</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda" src="assets/images/icones/icon-lista-produto.svg">
                            <h2 class="h4">Listas de produtos</h2>

                            <ul class="list-unstyled">
                                <li><a href="minha-conta-lista-produto.php" title="Minhas listas">Minhas listas</a></li>
                                <li><a href="javascrip:void(0);" title="Criar nova lista">Criar nova lista</a></li>
                            </ul>
                        </div>

                        <div class="sidebar-item">
                            <img class="sidebar-item-icone-esquerda"
                                 src="assets/images/icones/icon-lista-contribuicao.svg">
                            <h2 class="h4">Listas de contribuições</h2>

                            <ul class="list-unstyled">
                                <li><a href="javascrip:void(0);" title="Minhas contribuições">Minhas contribuições</a></li>
                                <li><a href="javascrip:void(0);" title="Submeter sugestões">Submeter sugestões</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>