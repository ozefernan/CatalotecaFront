<div class="pg-home">
    <?php
    $pg = "home";
    $titulo = "Bem-vindo à Cataloteca";
    $description = "Dados saneados e completos para itens MRO de forma simples e prática";
    include('head.php');
    include('menu-pesquisa.php');
    include('menu-categoria.php');
    ?>

    <!-- Banner -->
    <section class="s-banner-topo-home">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-10 col-md-9 s-banner-topo-home-b-conteudo">

                    <h1 class="s-banner-topo-home-titulo">Dados saneados e completos para itens MRO de forma simples e
                        prática. Somos a Cataloteca!</h1>

                    <div class="row s-banner-topo-home-row-itens">
                        <div class="col-xs-12 col-sm-6 col-md-5 s-banner-topo-home-col-item">
                            <h3 class="s-banner-topo-home-col-item-titulo">Pesquisar produtos</h3>
                            <p>Tenha acesso a informações de milhares de produtos com informações ricas com filtros de
                                busca
                                simples e práticos</p>

                            <a class="btn btn-cta-home btn-cta-home-blue btn-icon btn-icon-pesquisa-produto" href="#"
                               title="Pesquise por produtos">Pesquise
                                por produtos</a>

                        </div>

                        <div class="col-xs-12 col-sm-6 col-md-5 s-banner-topo-home-col-item">
                            <h3 class="s-banner-topo-home-col-item-titulo">Utilizar minha base de dados</h3>
                            <p>Utilize a Cataloteca como sua base de produtos, tendo seus dados atualizados de forma
                                àgil e
                                segura.</p>

                            <a class="btn btn-cta-home btn-cta-home-green btn-icon btn-icon-cadastrar" href="#"
                               title="Cadastre-se para acessar">Cadastre-se
                                para acessar</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /Banner -->

    <!-- Seção Sobre -->
    <section class="s-padrao s-sobre-home">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <div class="s-sobre-home-conteudo text-center">
                        <h2 class="titulo-secao">Cansado de fazer compras erradas de itens MRO por falta de
                            especificações?</h2>
                        <p>A Cataloteca é uma plataforma que faz o saneamento de dados de milhares de produtos,
                            consolidando
                            informações de diferentes bases de dados, criando um banco de dados confiável e informações
                            completas sobre produtos técnicos.</p>
                        <a class="btn btn-link" href="#" title="Experimente e faça uma pesquisa agora!">Experimente e
                            faça
                            uma
                            pesquisa agora!</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /Seção Sobre -->

    <!-- Seção o que fazemos -->
    <section class="s-padrao s-o-que-fazemos-home">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <img class="img-responsive" src="assets/images/home/img-s-o-que-fazemos.png">
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <h2 class="titulo-secao">Um modelo colaborativo para criar a maior base de dados saneados de itens
                        MRO
                        do Brasil</h2>
                    <p>Você pode fazer o upload de seus produtos para a Cataloteca via Excel ou XML. Nossa plataforma
                        fará o
                        saneamento das informações dos produtos cruzando com dados existentes na Cataloteca, mantendo
                        sempre
                        atualizado os dados dos itens informados.</p>
                    <a class="btn btn-cta-home btn-cta-home-orange " href="#"
                       title="Experimente e faça uma pesquisa agora!">Experimente e
                        faça
                        uma pesquisa agora!</a>
                </div>
                <div class="clearfix"></div>

                <div class="col-xs-12 col-sm-12 col-md-11 col-xs-offset-0 col-sm-offset-0 col-md-offset-1">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6 item-col">
                            <h3>Quem está por tras da Cataloteca?</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti nihil delectus odit
                                adipisci
                                quia
                                eligendi doloribus tempora quo, magni consectetur iure iste.</p>
                            <a class="btn btn-link" href="#" title="Saiba como surgiu a plataforma">Saiba como surgiu a
                                plataforma</a>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 item-col">
                            <h3>Ainda tem dúvidas?</h3>
                            <p>Somos uma plataforma moderna e inovadora para busca de itens MRO (produtos técnicos). Não
                                fique
                                preocupado se tiver dúvidas em como funciona a Cataloteca, respondemos as principais
                                perguntas
                                sobre
                                nossa ferramenta.</p>
                            <a class="btn btn-link" href="#" title="Quero tirar todas as minhas dúvidas!">Quero tirar
                                todas as
                                minhas dúvidas!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /Seção o que fazemos -->

    <?php include('footer.php'); ?>
</div>
