</body>

<!-- Footer -->
<footer>

    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-4">
                <h3>Menu de acesso</h3>
                <ul class="list-unstyled">
                    <li><a href="#" title="Para compradores MRO">Para compradores MRO</a></li>
                    <li><a href="#" title="Para fabricantes">Para fabricantes</a></li>
                    <li><a href="#" title="Sobre a Cataloteca">Sobre a Cataloteca</a></li>
                    <li><a href="contato.php" title="Contato">Contato</a></li>
                </ul>
            </div>

            <div class="col-xs-12 col-sm-4 col-md-4">
                <h3>Produtos MRO</h3>
                <ul class="list-unstyled">
                    <li><a href="#" title="Para compradores MRO">Encontrar produtos</a></li>
                    <li><a href="#" title="Para fabricantes">Cadastrar produtos</a></li>
                </ul>
            </div>

            <div class="col-xs-12 col-sm-4 col-md-4">
                <h3>Contato</h3>
                <div class="footer-dados-contato">
                    <p><a href="mailto:contato@cataloteca.com.br"
                          title="Envie-nos um e-mail">contato@cataloteca.com.br</a>
                    </p>

                    <p><a href="tel:+551155550000" title="Ligue para nós">+55 11 5555-0000</a> |
                        <a href="tel:+551155550000" title="Ligue para nós">+55 19 9999-0000</a></p>

                    <p><a href="#" title="Veja o endereço no mapa">Alameda Mamoré, 911 - Alphaville Industrial, Barueri
                            -
                            SP, 06454-040</a></p>

                    <ul class="list-inline footer-menu-social">
                        <li class="footer-menu-social-item-facebook"><a href="https://www.facebook.com/" target="_blank"
                                                                        title="Visite nossa página no Facebook">
                                <img src="assets/images/icones/icon-facebook-footer.svg"> cataloteca </a>
                        </li>
                        <li><a href="https://www.instagram.com/" target="_blank"
                               title="Siga-nos no Twitter"><img src="assets/images/icones/icon-twitter.png" style="height: 20px; width: auto">cataloteca</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="footer-logo">
                    <a href="index.html" title="Cataloteca"><img src="assets/images/cataloteca-logo.svg"
                                                                 alt="Cataloteca"> </a>
                </div>
            </div>

        </div>
    </div>
</footer>
<!-- /Footer -->

<!-- Copyright -->
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <ul class="list-inline no-margin ">
                    <li>&copy; 2019 - Cataloteca</li>
                    <li><a href="#" title="Termos e condições">Termos e condições</a></li>
                    <li><a href="#" title="Políticas de privacidade">Políticas de privacidade</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /Copyright -->


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


<!-- XZOOM JQUERY PLUGIN-->
<script type="text/javascript" src="https://unpkg.com/xzoom/dist/xzoom.min.js"></script>


<!-- Fancybox -->
<script type="text/javascript" src="https://payalord.github.io/xzoom-sandbox/FancyBoxVersion2/fancybox-2.1.7/source/jquery.fancybox.pack.js?v=2.1.7"></script>

<!-- Bundled JS -->
<script src="assets/js/main.min.js"></script>
<script src="assets/js/main.js"></script>

</html>