<div class="pg-contato">
    <?php
    $pg = 'contato';
    $titulo = 'Entre em contato conosco';
    $description = 'Entre em contato conosco e tire todas as suas dúvidas.';
    include('head.php');
    include('menu-pesquisa.php');
    include('menu-categoria.php');

    ?>

    <section class="s-padrao s-minha-conta" style="padding-top: 3em;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-8 col-xs-offset-0 col-sm-offset-2 col-md-offset-2">
                    <div class="s-minha-conta-conteudo">
                        <h2 class="h3 no-padding-bottom">Entre em contato conosco</h2>
                        <p style="padding-top: 1em; padding-bottom: 2em;">Preencha os abaixo e nos envie o seu contato</p>

                        <div class="s-minha-conta-conteudo-box">

                            <!--Formulário de edição de dados pessoais -->
                            <div class="s-minha-conta-formulario">
                                <form class="form form-minha-conta">
                                    <div class="form-group">
                                        <label for="lb_nome">Nome</label>
                                        <input type="text" class="form-control" id="lb_nome"
                                               placeholder="Nome">
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_email">E-mail</label>
                                        <input type="email" class="form-control" id="lb_email"
                                               placeholder="seu-melhor@email.com.br">
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_tel">Telefone</label>
                                        <input type="tel" class="form-control" id="lb_tel"
                                               placeholder="(00) 0000-0000">
                                    </div>

                                    <div class="form-group">
                                        <label for="sel1">Você é</label>
                                        <select class="form-control" id="sel1">
                                            <option value="comprador">Comprador MRO</option>
                                            <option value="fabricante">Fabricante</option>
                                            <option value="distribuidor">Distribuidor</option>

                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_assunto">Assunto</label>
                                        <input type="text" class="form-control" id="lb_assunto"
                                               placeholder="Qual o motivo do seu contato?">
                                    </div>

                                    <div class="form-group">
                                        <label for="lb_assunto">Mensagem</label><br>
                                        <textarea rows = "5"></textarea>
                                    </div>

                                    <!--                                            <button type="submit" class="btn btn-default btn-lg btn-block">Entrar-->
                                    <!--                                            </button>-->
                                    <a class="btn btn-default btn-lg" href="javascrip:void(0);">Enviar</a>
                                </form>
                            </div>
                            <!-- Fim Formulário de edição de dados pessoais -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>