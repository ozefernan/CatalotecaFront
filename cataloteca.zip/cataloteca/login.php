<div class="pg-login">
    <?php
    $pg = 'login';
    $titulo = 'Login';
    $description = 'Efetue login no sistema para acessar sua base de itens saneados.';
    include('head.php');
    include ('menu-pesquisa.php');
    include ('menu-categoria.php');
    ?>

    <section class="s-login">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="item-mro">
                        <div class="s-padrao">
                            <h2 class="h3">É um comprador MRO?</h2>
                            <p>Lorem ipsum dolor sit amet, sapien etiam, nunc amet dolor ac odio mauris justo.</p>
                            <div class="row">
                                <div class="col-md-10">
                                    <div class="b-conteudo-item-mro">
                                        <form class="form">
                                            <div class="form-group">
                                                <label for="lb_email">E-mail</label>
                                                <input type="email" class="form-control" id="lb_email"
                                                       placeholder="Insira o seu e-mail de cadastro">
                                            </div>
                                            <div class="form-group">
                                                <label for="lb_senha">Senha</label>
                                                <input type="password" class="form-control" id="lb_senha"
                                                       placeholder="Senha">
                                            </div>

                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox">Lembrar meu login
                                                </label>

                                                <a class="btn btn-link pull-right no-padding-top no-margin-top"
                                                   href="#">Esqueci minha senha</a>
                                            </div>

<!--                                            <button type="submit" class="btn btn-default btn-lg btn-block">Entrar-->
<!--                                            </button>-->
                                            <a class="btn btn-default btn-lg btn-block" href="minha-conta.php">Entrar</a>
                                        </form>

                                        <div class="b-item-mro-cadastre-se">
                                            <p class="traco-texto">ou</p>

                                            <p class="pull-left b-item-mro-cadastre-se-txt-chamada-cadastro">Ainda não é
                                                cadastrado?</p>
                                            <a class="btn btn-default btn-lg btn-traco pull-right no-margin-top"
                                               href="cadastro-mro.php">Cadastre-se</a>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 bg-xs">
                    <div class="item-distribuidor text-center">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="s-padrao">
                                    <h2 class="h3">É um fabricante ou distribuidor?</h2>
                                    <p>Lorem ipsum dolor sit amet, sapien etiam, nunc amet dolor ac odio mauris
                                        justo.</p>

                                    <div class="item-distribuidor-b-conteudo">
                                        <h4 class="h4 text-center">Já tenho cadastro</h4>
                                        <a class="btn btn-lg btn-default btn-outline" href="http://nanolab.com.br/cliente/cataloteca/painel">Login</a>

                                        <div class="b-item-distribuidor-cadastre-se">
                                            <p class="traco-texto">ou</p>

                                            <h4 class="h4">Quero cadastrar minha empresa</h4>
                                            <a class="btn btn-default btn-lg" href="#">Cadastre-se</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include('footer.php'); ?>
</div>
