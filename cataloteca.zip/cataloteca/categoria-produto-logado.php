<div class="pg-categoria-produto-logado">
    <?php
    $pg = 'categoria-produto-logado';
    $titulo = 'Categoria do produto quando o usuário fizer login';
    $description = 'Encontre produtos de uma categoria específica';
    include('head.php');
    include('menu-pesquisa-minha-conta.php');
    include('menu-categoria.php');
    ?>

    <section class="banner-topo">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="banner-topo-conteudo">
                        <h1 class="h1">Variedade em Iluminação LED</h1>
                        <p class="banner-topo-conteudo-descricao">Com mais de mil produtos de iluminação Led em nosso
                            catalogo
                            Veja, compare e avalie o melhor equipamento para sua empresa.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="s-padrao s-funcionalidades">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-10 col-md-10 col-sm-offset-1 col-md-offset-1">
                    <div class="s-funcionalidades-box">

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-3">
                                        <div class="s-funcionalidades-item">
                                            <img class="s-funcionalidades-item-icone"
                                                 src="assets/images/icones/icon-pesquisa-produto-funcionalidade.svg">
                                            <p>Pesquise por milhares de produtos</p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-sm-6 col-md-3">
                                        <div class="s-funcionalidades-item">
                                            <img class="s-funcionalidades-item-icone"
                                                 src="assets/images/icones/icon-encontre-produto.svg">
                                            <p>Encontre produtos com dados seneados</p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-sm-6 col-md-3">
                                        <div class="s-funcionalidades-item">
                                            <img class="s-funcionalidades-item-icone"
                                                 src="assets/images/icones/icon-check.svg">
                                            <p>Encontre produtos com dados seneados</p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-sm-6 col-md-3">
                                        <div class="s-funcionalidades-item">
                                            <img class="s-funcionalidades-item-icone"
                                                 src="assets/images/icones/icon-alvo.svg">
                                            <p>Encontre produtos com dados seneados</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Produtos sugeridos pra você -->
    <section class="s-produto-sugerido-voce s-padrao no-padding-top">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="">
                        <h2 class="h3">Produtos sugeridos para você</h2>
                        <p class="descricao-secao">A sugestão de produtos é feito de acordo com sua navegação e
                            histórico de pesquisa</p>

                        <div class="c-lista-produto">
                            <div class="row">

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-1.png"
                                                     alt="Interruptor Fuga Dr C/2 Polos 125a 30ma - Steck">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos
                                                125a 30ma - Steck</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-1.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos
                                                125a 30ma - Steck</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-3.png"
                                                     alt="IPlug Industrial 3p 32a 220v 6h 3276 Azul">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">IPlug Industrial 3p 32a 220v 6h
                                                3276 Azul</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/lampada-philips-2.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Philips Led. Equiv. 75x branco
                                                quente suave</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/lampada-philips-2.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Philips Led. Equiv. 75x branco
                                                quente suave</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/prod-3.png"
                                                     alt="IPlug Industrial 3p 32a 220v 6h 3276 Azul">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">IPlug Industrial 3p 32a 220v 6h
                                                3276 Azul</h2>
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xs-6 col-sm-4 col-md-3">
                                    <div class="c-lista-produto-item">
                                        <a href="detalhe-produto.php" title="Acesse esse produto">
                                            <div class="c-lista-produto-item-img">
                                                <img src="assets/images/produto/lampada-philips-2.png"
                                                     alt="Philips Led. Equiv. 75x branco quente suave">
                                            </div>

                                            <div class="c-lista-produto-item-fabricante">
                                                <div class="c-lista-produto-item-fabricante-img">
                                                    <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                                </div>
                                            </div>

                                            <h2 class="c-lista-produto-item-titulo h4">Philips Led. Equiv. 75x branco
                                                quente suave</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Fim Produtos sugeridos pra você -->


    <!-- Produtos sugeridos -->
    <section class="s-padrao s-produto-sugerido" style="background-color: #f3f3f3;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Produtos sugeridos para você nesta categoria:</h2>
                </div>
                <div class="slide-produto slide-produto-default">
                    <div class="MultiCarousel" data-items="2,3,4,4" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ourolux-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 01">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/ge-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-1.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/galaxy-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Fuga Dr C/2 Polos 125a 30ma
                                            - Steck</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/prod-2.png"
                                                 alt="Produto 02">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/brilia-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Interruptor Simples Miluz Sobrepor
                                            S3b66100</h2>
                                    </div>
                                </a>
                            </div>

                            <div class="item slide-produto-item">
                                <a href="detalhe-produto.php" title="Acesse esse produto">
                                    <div class="pad15">
                                        <div class="slide-produto-item-img">
                                            <img src="assets/images/produto/lampada-philips-2.png"
                                                 alt="Philips Led. Equiv. 75x branco quente suave">
                                        </div>

                                        <div class="slide-produto-item-fabricante">
                                            <div class="slide-produto-item-fabricante-img">
                                                <img src="assets/images/fabricante/philips-2.png" alt="Philips">
                                            </div>
                                        </div>

                                        <h2 class="slide-produto-item-titulo h4">Philips Led. Equiv. 75x branco quente
                                            suave</h2>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-arrow leftLst"><</button>
                        <button class="btn btn-primary btn-arrow rightLst">></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Fim Produtos sugeridos -->

    <!-- Categorias visitadas -->
    <section class="s-padrao s-quem-visitou-categoria">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h2 class="h3">Quem visitou esta categoria também viu estes produtos:</h2>
                    <p class="descricao-secao">Navegue entre as categorias com itens mais pesquisados na plataforma Cataloteca</p>
                </div>
                <div class="slide-produto slide-produto-small">
                    <div class="MultiCarousel" data-items="2,3,5,6" data-slide="2" id="MultiCarousel"
                         data-interval="1000">

                        <div class="MultiCarousel-inner">
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <div class="b-slide-produto-item-img">
                                                <img src="assets/images/produtos/quem-visitou/cabos-e-fios-1.png" alt=""
                                                     class="slide-produto-item-img">
                                            </div>
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Cabos e fios
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/componentes-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Componentes Elétricos
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/eletroduto-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Eletroduto
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/extensoes-filtros-1.png"
                                                 alt="" class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Extensões e filtros de linha
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/interruptor-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Interruptor
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/seguranca-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Segurança elétrica
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <div class="b-slide-produto-item-img">
                                                <img src="assets/images/produtos/quem-visitou/cabos-e-fios-1.png" alt=""
                                                     class="slide-produto-item-img">
                                            </div>
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Cabos e fios
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/componentes-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Componentes Elétricos
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/eletroduto-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Eletroduto
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/extensoes-filtros-1.png"
                                                 alt="" class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Extensões e filtros de linha
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/interruptor-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Interruptor
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item slide-produto-item">
                                <a href="categoria-produto.php">
                                    <div class="pad15">
                                        <div class="b-slide-produto-item-img">
                                            <img src="assets/images/produtos/quem-visitou/seguranca-1.png" alt=""
                                                 class="slide-produto-item-img">
                                        </div>

                                        <div class="b-slide-produto-item-titulo">
                                            <h3 class="slide-produto-item-titulo">
                                                Segurança elétrica
                                            </h3>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-arrow leftLst">
                            <
                        </button>
                        <button class="btn btn-primary btn-arrow rightLst">>
                        </button>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <a class="btn btn-default btn-lg" href="#">Ver todas as categorias</a>
                </div>

            </div>
        </div>
    </section>
    <!-- Fim Categorias visitadas -->


    <?php include('footer.php'); ?>
</div>
