$(document).ready(function () {

    //Configurações Slide
    var itemsMainDiv = ('.MultiCarousel');
    var itemsDiv = ('.MultiCarousel-inner');
    var itemWidth = "";

    $('.leftLst, .rightLst').click(function () {
        var condition = $(this).hasClass("leftLst");
        if (condition)
            click(0, this);
        else
            click(1, this)
    });

    ResCarouselSize();

    $(window).resize(function () {
        ResCarouselSize();
    });

    //this function define the size of the items
    function ResCarouselSize() {
        var incno = 0;
        var dataItems = ("data-items");
        var itemClass = ('.item');
        var id = 0;
        var btnParentSb = '';
        var itemsSplit = '';
        var sampwidth = $(itemsMainDiv).width();
        var bodyWidth = $('body').width();
        $(itemsDiv).each(function () {
            id = id + 1;
            var itemNumbers = $(this).find(itemClass).length;
            btnParentSb = $(this).parent().attr(dataItems);
            itemsSplit = btnParentSb.split(',');
            $(this).parent().attr("id", "MultiCarousel" + id);


            if (bodyWidth >= 1200) {
                incno = itemsSplit[3];
                itemWidth = sampwidth / incno;
            } else if (bodyWidth >= 992) {
                incno = itemsSplit[2];
                itemWidth = sampwidth / incno;
            } else if (bodyWidth >= 768) {
                incno = itemsSplit[1];
                itemWidth = sampwidth / incno;
            } else {
                incno = itemsSplit[0];
                itemWidth = sampwidth / incno;
            }
            $(this).css({'transform': 'translateX(0px)', 'width': itemWidth * itemNumbers});
            $(this).find(itemClass).each(function () {
                $(this).outerWidth(itemWidth);
            });

            $(".leftLst").addClass("over");
            $(".rightLst").removeClass("over");

        });
    }


    //this function used to move the items
    function ResCarousel(e, el, s) {
        var leftBtn = ('.leftLst');
        var rightBtn = ('.rightLst');
        var translateXval = '';
        var divStyle = $(el + ' ' + itemsDiv).css('transform');
        var values = divStyle.match(/-?[\d\.]+/g);
        var xds = Math.abs(values[4]);
        if (e == 0) {
            translateXval = parseInt(xds) - parseInt(itemWidth * s);
            $(el + ' ' + rightBtn).removeClass("over");

            if (translateXval <= itemWidth / 2) {
                translateXval = 0;
                $(el + ' ' + leftBtn).addClass("over");
            }
        } else if (e == 1) {
            var itemsCondition = $(el).find(itemsDiv).width() - $(el).width();
            translateXval = parseInt(xds) + parseInt(itemWidth * s);
            $(el + ' ' + leftBtn).removeClass("over");

            if (translateXval >= itemsCondition - itemWidth / 2) {
                translateXval = itemsCondition;
                $(el + ' ' + rightBtn).addClass("over");
            }
        }
        $(el + ' ' + itemsDiv).css('transform', 'translateX(' + -translateXval + 'px)');
    }

    //It is used to get some elements from btn
    function click(ell, ee) {
        var Parent = "#" + $(ee).parent().attr("id");
        var slide = $(Parent).attr("data-slide");
        ResCarousel(ell, Parent, slide);
    }

    //FIM Configurações Slide
});

// MEGA MENU CATEGORIAS
$('.c-mega-menu-categorias > .mega-dropdown').on('mouseover', function (e) {
    $(this).find(".mega-dropdown-menu:first").show();
    $(this).find('> a').addClass('active');
}).on('mouseout', function (e) {
    $(this).find(".mega-dropdown-menu:first").hide();
    $(this).find('> a').removeClass('active');
});

$('.c-mega-menu-categorias .mega-dropdown .mega-dropdown-menu li').on('mouseover', function (e) {
    if ($(this).has('.mega-dropdown-submenu').length) {
        $(this).parent().addClass('expanded');
    }
    $('.mega-dropdown-submenu:first', this).parent().find('> a').addClass('active');
    $('.mega-dropdown-submenu:first', this).show();
}).on('mouseout', function (e) {
    $(this).parent().removeClass('expanded');
    $('.mega-dropdown-submenu:first', this).parent().find('> a').removeClass('active');
    $('.mega-dropdown-submenu:first', this).hide();
});

//FIM MENU CATEGORIAS

// HABILITA BOOTSTRAP POPOVER
$(document).ready(function () {

    // Inicializa o popover
    $('[data-toggle="popover"]').popover();

    // Quando voce clica num popover ele mostra o que ta e esconde todos os outros
    $('[data-toggle="popover"]').on('click', function (e) {
        $('[data-toggle="popover"]').not(this).popover('hide');
    });

    // Quando clica no icone de X no popover esconde ele mesmo
    $(document).on("click", '.popover .close[data-dismiss="popover"]', function () {
        $(this).parents(".popover").popover('hide');
    });

    // Quando o popover aparece rola a tela pra onde ele ta
    $('[data-toggle="popover"]').on('shown.bs.popover', function () {
        $('html, body').animate({
            scrollTop: $("div.popover").offset().top - 100
        }, 500);
    });

    // Corrige click fantasma no elemento do popover quando ele é fechado manualmente
    $('[data-toggle="popover"]').on('hidden.bs.popover', function (e) {
        $(e.target).data("bs.popover").inState.click = false;
    });

});


//CAROUSEL DAS THUMBS DA GALERIA
$(document).ready(function () {
    var carousel_items = 4;
    $('.carousel[data-type="multi"] .item').each(function () {
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));

        for (var i = 0; i < (carousel_items - 2); i++) {
            next = next.next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }

            next.children(':first-child').clone().appendTo($(this));
        }
    });
});

// HABILITA O XZOOM GALLERY
$(document).ready(function () {
    $(".xzoom-wrapper .xzoom, .xzoom-wrapper .xzoom-gallery").xzoom({
        Xoffset: 42, // 1.5em with 14px font base
        Yoffset: 21, // 1.5em with 14px font base
        lens: '#FF6F5A'
    });

    //Integration with FancyBox 2 plugin
    $('.xzoom:first').bind('click', function (e) {

        var xzoom = $(this).data('xzoom');
        xzoom.closezoom();
        $.fancybox.open(xzoom.gallery().cgallery);
        e.preventDefault();
    });


    //Set thumbnail active
    $('.xzoom-gallery').bind('click', function (e) {
        var parent_class = '.c-galeria-produto-listagem-thumbnail-item';

        var current_src = $(this).attr('src');

        $('.xzoom-thumbs').find(parent_class).each(function () {
            var $same_src = $(this).find('.xzoom-gallery[src="' + current_src + '"]');
            if ($same_src.length > 0) {
                $(this).addClass('xactive');
            } else {
                $(this).removeClass('xactive');
            }
        });

    });
});