<div class="pg-todas-categorias">
    <?php
    $pg = 'todas-categorias';
    $titulo = 'Todas as Categorias de Produtos';
    $description = 'Todas as Categorias de Produtos';
    include('head.php');
    include('menu-pesquisa.php');
    include('menu-categoria.php');

    ?>

    <section class="s-padrao s-listagem-todas-categorias" style="padding-top: 3em; background-color: #f9f9f9;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">

                    <h1 class="h3">Lista de todas as categorias de produtos</h1>

                    <div class="listagem-todas-categorias-box">
                        <div class="row listagem-todas-categorias-item-categoria">
                            <!--Item -->
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <h2 class="h3"><a title="Materiais Elétricos" href="categoria-produto.php">Materiais Elétricos</a></h2>
                            </div>
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Interruptor e tomada" href="categoria-produto.php">Interruptor e tomada</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Disjuntor e Caixas" href="categoria-produto.php">Disjuntor e Caixas</a></li>
                                        <li><a title="Tomada" href="categoria-produto.php">Tomada</a></li>
                                        <li><a title="Placas e Conjunto" href="categoria-produto.php">Placas e Conjuntos</a></li>
                                        <li><a title="Campainhas" href="categoria-produto.php">Campainhas</a></li>
                                        <li><a title="Interruptor" href="categoria-produto.php">Interruptor</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Cabos e Fios" href="categoria-produto.php">Cabos e Fios</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Organização de cabos" href="categoria-produto.php">Organização de cabos</a></li>
                                        <li><a title="Eletroduto" href="categoria-produto.php">Eletroduto</a></li>
                                        <li><a title="Cabo PP" href="categoria-produto.php">Cabo PP</a></li>
                                        <li><a title="Condulete" href="categoria-produto.php">Condulete</a></li>
                                        <li><a title="Cabos Flexíveis 750v" href="categoria-produto.php">Cabos Flexíveis 750v</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Iluminação" href="categoria-produto.php">Iluminação</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Luminárias" href="categoria-produto.php">Luminárias</a></li>
                                        <li><a title="Soquete" href="categoria-produto.php">Soquete</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Componentes Elétricos" href="categoria-produto.php">Componentes Elétricos</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Resistência" href="categoria-produto.php">Resistência</a></li>
                                        <li><a title="Conectores" href="categoria-produto.php">Conectores</a></li>
                                        <li><a title="Conduítes" href="categoria-produto.php">Conduítes</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Terminais</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <div class="clearfix"></div>

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Instalação Elétrica" href="categoria-produto.php">Instalação Elétrica</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Terminais" href="categoria-produto.php">Cabo Flexível 1KVA</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Fitas Isolantes</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Extensões e Filtros de Linha</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Terminais</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Disjuntores</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Quadros e Caixas Elétricas</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Cintadores e Reles</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Instalação Elétrica" href="categoria-produto.php">Segurança Elétrica</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Sensores" href="categoria-produto.php">Sensores</a></li>
                                        <li><a title="Iluminação de Emergência" href="categoria-produto.php">Iluminação de Emergência</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Sensores" href="categoria-produto.php">Acessórios de componentes</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Fitas Isolantes" href="categoria-produto.php">Fitas Isolantes</a></li>
                                        <li><a title="Iluminação de Emergência" href="categoria-produto.php">Iluminação de Emergência</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->
                        </div>
                        <div class="clearfix"></div>


                        <div class="row listagem-todas-categorias-item-categoria">
                            <!--Item -->
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <h2 class="h3"><a title="Higiêne e limpeza" href="categoria-produto.php">Higiêne e limpeza</a></h2>
                            </div>
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Interruptor e tomada" href="categoria-produto.php">Interruptor e tomada</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Disjuntor e Caixas" href="categoria-produto.php">Disjuntor e Caixas</a></li>
                                        <li><a title="Tomada" href="categoria-produto.php">Tomada</a></li>
                                        <li><a title="Placas e Conjunto" href="categoria-produto.php">Placas e Conjuntos</a></li>
                                        <li><a title="Campainhas" href="categoria-produto.php">Campainhas</a></li>
                                        <li><a title="Interruptor" href="categoria-produto.php">Interruptor</a></li>
                                    </ul>

                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Cabos e Fios" href="categoria-produto.php">Cabos e Fios</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Organização de cabos" href="categoria-produto.php">Organização de cabos</a></li>
                                        <li><a title="Eletroduto" href="categoria-produto.php">Eletroduto</a></li>
                                        <li><a title="Cabo PP" href="categoria-produto.php">Cabo PP</a></li>
                                        <li><a title="Condulete" href="categoria-produto.php">Condulete</a></li>
                                        <li><a title="Cabos Flexíveis 750v" href="categoria-produto.php">Cabos Flexíveis 750v</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Iluminação" href="categoria-produto.php">Iluminação</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Luminárias" href="categoria-produto.php">Luminárias</a></li>
                                        <li><a title="Soquete" href="categoria-produto.php">Soquete</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->

                            <!--Item -->
                            <div class="col-xs-12 col-sm-3 col-md-3">
                                <div class="listagem-todas-categorias-item">
                                    <h2 class="h4"><a title="Componentes Elétricos" href="categoria-produto.php">Componentes Elétricos</a></h2>

                                    <ul class="list-unstyled listagem-todas-categorias-lista">
                                        <li><a title="Resistência" href="categoria-produto.php">Resistência</a></li>
                                        <li><a title="Conectores" href="categoria-produto.php">Conectores</a></li>
                                        <li><a title="Conduítes" href="categoria-produto.php">Conduítes</a></li>
                                        <li><a title="Terminais" href="categoria-produto.php">Terminais</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!--Fim Item -->
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php include('footer.php'); ?>
</div>
